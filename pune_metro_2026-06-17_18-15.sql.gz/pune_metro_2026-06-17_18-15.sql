-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: pune_metro
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.24.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board_members`
--

DROP TABLE IF EXISTS `board_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board_members` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci,
  `media_id` bigint unsigned DEFAULT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `board_members_media_id_foreign` (`media_id`),
  KEY `board_members_sort_order_index` (`sort_order`),
  CONSTRAINT `board_members_media_id_foreign` FOREIGN KEY (`media_id`) REFERENCES `media` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board_members`
--

LOCK TABLES `board_members` WRITE;
/*!40000 ALTER TABLE `board_members` DISABLE KEYS */;
INSERT INTO `board_members` VALUES (1,'Dr. Praveer Sinha','Chairman','<p class=\"p1\" style=\"font-style: normal; font-variant: normal; font-size-adjust: none; font-language-override: normal; font-kerning: auto; font-optical-sizing: auto; font-feature-settings: normal; font-variation-settings: normal; font-stretch: normal; font-size: 13px; line-height: normal; font-family: &quot;Helvetica Neue&quot;; color: rgb(0, 0, 0);\">Dr. Praveer Sinha is the CEO &amp; Managing Director of The Tata Power Company Limited, one of India\'s oldest and largest integrated power utilities. A seasoned power sector professional with a career spanning almost four decades, Dr. Sinha has held several leadership positions across the power sector value chain.</p><p class=\"p2\" style=\"font-style: normal; font-variant: normal; font-size-adjust: none; font-language-override: normal; font-kerning: auto; font-optical-sizing: auto; font-feature-settings: normal; font-variation-settings: normal; font-stretch: normal; font-size: 13px; line-height: normal; font-family: &quot;Helvetica Neue&quot;; min-height: 15px; color: rgb(0, 0, 0);\">&nbsp;</p><p class=\"p1\" style=\"font-style: normal; font-variant: normal; font-size-adjust: none; font-language-override: normal; font-kerning: auto; font-optical-sizing: auto; font-feature-settings: normal; font-variation-settings: normal; font-stretch: normal; font-size: 13px; line-height: normal; font-family: &quot;Helvetica Neue&quot;; color: rgb(0, 0, 0);\">As CEO and MD of Tata Power Delhi Distribution Limited, he was instrumental in driving the turnaround of the DISCOM&nbsp; through technological and social interventions and setting a benchmark operational model for other DISCOMs and developing countries to follow.</p><p class=\"p2\" style=\"font-style: normal; font-variant: normal; font-size-adjust: none; font-language-override: normal; font-kerning: auto; font-optical-sizing: auto; font-feature-settings: normal; font-variation-settings: normal; font-stretch: normal; font-size: 13px; line-height: normal; font-family: &quot;Helvetica Neue&quot;; min-height: 15px; color: rgb(0, 0, 0);\">&nbsp;</p><p class=\"p1\" style=\"font-style: normal; font-variant: normal; font-size-adjust: none; font-language-override: normal; font-kerning: auto; font-optical-sizing: auto; font-feature-settings: normal; font-variation-settings: normal; font-stretch: normal; font-size: 13px; line-height: normal; font-family: &quot;Helvetica Neue&quot;; color: rgb(0, 0, 0);\">Under his current leadership, Tata Power is at the forefront of transforming itself from a century old power utility company into a new-aged sustainable, technology oriented and customer centric green energy solutions company.</p><p class=\"p2\" style=\"font-style: normal; font-variant: normal; font-size-adjust: none; font-language-override: normal; font-kerning: auto; font-optical-sizing: auto; font-feature-settings: normal; font-variation-settings: normal; font-stretch: normal; font-size: 13px; line-height: normal; font-family: &quot;Helvetica Neue&quot;; min-height: 15px; color: rgb(0, 0, 0);\">&nbsp;</p><p class=\"p1\" style=\"font-style: normal; font-variant: normal; font-size-adjust: none; font-language-override: normal; font-kerning: auto; font-optical-sizing: auto; font-feature-settings: normal; font-variation-settings: normal; font-stretch: normal; font-size: 13px; line-height: normal; font-family: &quot;Helvetica Neue&quot;; color: rgb(0, 0, 0);\">Dr. Sinha has led multiple partnerships with national and international technology partners and institutional associations. He has contributed significantly to setting up the first international incubator in India for promoting innovations in the clean energy space.</p><p class=\"p2\" style=\"font-style: normal; font-variant: normal; font-size-adjust: none; font-language-override: normal; font-kerning: auto; font-optical-sizing: auto; font-feature-settings: normal; font-variation-settings: normal; font-stretch: normal; font-size: 13px; line-height: normal; font-family: &quot;Helvetica Neue&quot;; min-height: 15px; color: rgb(0, 0, 0);\">&nbsp;</p><p class=\"p1\" style=\"font-style: normal; font-variant: normal; font-size-adjust: none; font-language-override: normal; font-kerning: auto; font-optical-sizing: auto; font-feature-settings: normal; font-variation-settings: normal; font-stretch: normal; font-size: 13px; line-height: normal; font-family: &quot;Helvetica Neue&quot;; color: rgb(0, 0, 0);\">He is the chairman of the CIl Western Region Council and co-chairs the CII National Committee on Power.</p><p class=\"p2\" style=\"font-style: normal; font-variant: normal; font-size-adjust: none; font-language-override: normal; font-kerning: auto; font-optical-sizing: auto; font-feature-settings: normal; font-variation-settings: normal; font-stretch: normal; font-size: 13px; line-height: normal; font-family: &quot;Helvetica Neue&quot;; min-height: 15px; color: rgb(0, 0, 0);\">&nbsp;</p><p class=\"p1\" style=\"font-style: normal; font-variant: normal; font-size-adjust: none; font-language-override: normal; font-kerning: auto; font-optical-sizing: auto; font-feature-settings: normal; font-variation-settings: normal; font-stretch: normal; font-size: 13px; line-height: normal; font-family: &quot;Helvetica Neue&quot;; color: rgb(0, 0, 0);\">Dr. Sinha is a qualified electrical engineer and has also completed his master\'s in business law. He received his PhD from the Indian Institute of Technology, Delhi, and is a visiting research associate at the Massachusetts Institute of Technology (MIT), Boston, USA.</p>',92,0,1,'2026-05-19 11:41:24','2026-06-16 07:14:05'),(2,'Dr. Mangu Singh','Independent Director','A Civil Engineering graduate from IIT Roorkee, Dr. Singh served as MD of Delhi Metro Rail Corporation (DMRC) for about 10 years, overseeing commissioning of more than 300 km of metro network. He successfully led the first CDM project under UNFCCC in the metro rail sector, earning carbon credits for DMRC. He is a recipient of the National Railway Week Award and the Distinguished Alumnus Award from IIT Roorkee.',91,1,1,'2026-05-19 11:41:24','2026-05-20 17:08:45'),(3,'Mr. Sudip Mullick','Independent Director','A Partner at Economic Laws Practice specialising in Real Estate, Construction and Hospitality, Mr. Mullick has over three decades of legal experience. He holds a law degree from Calcutta University and completed a leadership programme at Harvard University in 2017. He is consistently recognised in Chambers, Legal 500, and Benchmark Litigation, and was named an Elite Practitioner by Asia Law in 2024–25.',89,2,1,'2026-05-19 11:41:24','2026-05-20 06:21:03'),(4,'Mr. Basil Watters','Director','A Project Finance expert with 20 years of experience across a London-based international law firm, an international development bank, and a leading global engineering company. He has worked in the United Kingdom, India, and Germany in roles spanning external counsel, internal counsel, and Chief Operations Officer for South Asia. He brings a diverse skill set across debt, equity, and operations.',93,3,1,'2026-05-19 11:41:24','2026-05-20 17:09:16'),(5,'Ms. Sukriti Sood','Director','Ms. Sood brings over 18 years of experience in financial services and has been with Siemens Financial Services since 2013, currently leading India\'s equity investments business. She holds a degree in Civil Engineering from Delhi College of Engineering, an MBA from SP Jain Institute of Management and Research, and a Master\'s in Finance from London Business School.',95,4,1,'2026-05-19 11:41:24','2026-05-20 06:21:28'),(6,'Mr. Rajan Kapoor','Alternate Director to Mr. Basil Watters','A finance professional with 15 years of experience in treasury management, corporate banking, and project financing, Mr. Kapoor currently manages asset investments for Pune Metro and healthcare fund investments in Asia within Siemens. Prior to his equity finance role, he managed financial risk for Siemens India group companies and handled debt syndication and equity investments at Central Bank of India. He holds extensive expertise across both corporate and banking environments.',88,6,1,'2026-05-19 11:41:24','2026-06-11 06:08:53'),(7,'Mr. Anil Kumar Saini','Chief Executive Officer','Mr. Saini brings over three decades of leadership experience in project management, operations, and business development across the rail transport sector, including stints at  Indian Railways, DMRC, L&T, and Alstom Transport. He holds a B.Tech in Electrical Engineering from IIT Roorkee and an Executive MBA from Harvard Business School.',96,7,1,'2026-05-19 11:41:24','2026-06-11 06:07:27'),(8,'Mr. Mitul Jhaveri','Chief Financial Officer','Mr. Jhaveri brings 22+ years of experience in corporate finance, M&A advisory, project finance, and equity finance. He worked in Siemens from 2007-2025. He has previously worked with ICICI Bank and Indian Oil Corporation in their international banking and finance divisions. He is a Chartered Accountant and MBA from Jamanalal Bajaj Institute of Management Studies.',97,8,1,'2026-05-19 11:41:24','2026-06-11 06:07:39'),(9,'Ms. Anjali Gupta','Company Secretary','A qualified Company Secretary, Law Graduate, and MBA in Finance, Ms. Gupta has around 9 years of experience in secretarial and compliance functions. She has previously been associated with Aditya Birla Renewables, Sekura Roads, and Grauer & Weil India, handling board meetings, fund raising, mergers, and SPV incorporations. She brings strong expertise in corporate governance and statutory compliance.',90,9,1,'2026-05-19 11:41:24','2026-06-11 06:07:49'),(10,'Ms. K Manjulekshmi','Director nominated by Pune Metropolitan Region Development Authority','A 2013 batch IAS officer of the Maharashtra cadre, she has held key roles including Collector & DM Sindhudurg, Municipal Commissioner of Kolhapur Municipal Corporation, and CEO of Zilla Parishad Sindhudurg. She currently serves as Additional Metropolitan Commissioner, PMRDA since April 2026.',87,5,1,'2026-05-19 11:41:24','2026-06-11 06:09:01');
/*!40000 ALTER TABLE `board_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES ('pune-metro-cache-031f89b3d6b2208a681e2224fedc25c6','i:1;',1781593840),('pune-metro-cache-031f89b3d6b2208a681e2224fedc25c6:timer','i:1781593840;',1781593840),('pune-metro-cache-0b79528cd775c47e0253fc37705ec426','i:1;',1781693077),('pune-metro-cache-0b79528cd775c47e0253fc37705ec426:timer','i:1781693077;',1781693077),('pune-metro-cache-1cc10750478572c83584f9c398532d8c','i:1;',1779296881),('pune-metro-cache-1cc10750478572c83584f9c398532d8c:timer','i:1779296881;',1779296881),('pune-metro-cache-3976fb2cbef3857d953139aba265dc15','i:1;',1781681752),('pune-metro-cache-3976fb2cbef3857d953139aba265dc15:timer','i:1781681752;',1781681752),('pune-metro-cache-81d855873608ac209c4953d9fd5bca77','i:1;',1781679017),('pune-metro-cache-81d855873608ac209c4953d9fd5bca77:timer','i:1781679017;',1781679017),('pune-metro-cache-admin@example.com|117.235.180.8','i:1;',1781593979),('pune-metro-cache-admin@example.com|117.235.180.8:timer','i:1781593979;',1781593979),('pune-metro-cache-b7644cb1e629ea0fffc1afea9f49d315','i:1;',1779959235),('pune-metro-cache-b7644cb1e629ea0fffc1afea9f49d315:timer','i:1779959235;',1779959235),('pune-metro-cache-bf0e5b810831e78d52ad3bd37353da20','i:1;',1781593979),('pune-metro-cache-bf0e5b810831e78d52ad3bd37353da20:timer','i:1781593979;',1781593979),('pune-metro-cache-d21a8e109a7583c66798502f0113c847','i:1;',1779258079),('pune-metro-cache-d21a8e109a7583c66798502f0113c847:timer','i:1779258079;',1779258079),('pune-metro-cache-d91d11e87fc455ec6245e6fb7a761795','i:1;',1779256847),('pune-metro-cache-d91d11e87fc455ec6245e6fb7a761795:timer','i:1779256847;',1779256847),('pune-metro-cache-dc2b985c29d3b97db1c8cc715628d83a','i:1;',1781594029),('pune-metro-cache-dc2b985c29d3b97db1c8cc715628d83a:timer','i:1781594029;',1781594029),('pune-metro-cache-e002723cca795251e5b98c85bc7b9253','i:1;',1779860460),('pune-metro-cache-e002723cca795251e5b98c85bc7b9253:timer','i:1779860460;',1779860460),('pune-metro-cache-e0e61e56a0518ecc483f74ad762e95cc','i:1;',1779800086),('pune-metro-cache-e0e61e56a0518ecc483f74ad762e95cc:timer','i:1779800086;',1779800086),('pune-metro-cache-e14786be660f76cd0bfeab1c423bc46b','i:1;',1781174767),('pune-metro-cache-e14786be660f76cd0bfeab1c423bc46b:timer','i:1781174767;',1781174767),('pune-metro-cache-febbbbec3257c0c2b9f3966d7ef58e25','i:1;',1781517766),('pune-metro-cache-febbbbec3257c0c2b9f3966d7ef58e25:timer','i:1781517766;',1781517766);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'News & Updates','news-updates','Latest news, announcements, and updates from Pune Metro Rail.','2026-05-13 10:09:29','2026-05-13 10:09:29'),(2,'Stations & Routes','stations-routes','Information about metro stations, corridors, and route maps.','2026-05-13 10:09:29','2026-05-13 10:09:29'),(3,'Project Progress','project-progress','Construction milestones, civil work updates, and project timelines.','2026-05-13 10:09:29','2026-05-13 10:09:29'),(4,'Fares & Ticketing','fares-ticketing','Ticket prices, smart card details, and payment methods.','2026-05-13 10:09:29','2026-05-13 10:09:29'),(5,'Commuter Guide','commuter-guide','Travel tips, schedules, entry/exit rules, and passenger information.','2026-05-13 10:09:29','2026-05-13 10:09:29'),(6,'Safety & Accessibility','safety-accessibility','Passenger safety protocols, accessibility features, and emergency guidelines.','2026-05-13 10:09:29','2026-05-13 10:09:29'),(7,'Environment & Sustainability','environment-sustainability','Green initiatives, energy efficiency, and environmental impact of Pune Metro.','2026-05-13 10:09:29','2026-05-13 10:09:29'),(8,'Technology & Innovation','technology-innovation','CBTC signalling, automatic train operation, and smart metro systems.','2026-05-13 10:09:29','2026-05-13 10:09:29'),(9,'Tenders & Contracts','tenders-contracts','Official tenders, contract awards, and procurement notices.','2026-05-13 10:09:29','2026-05-13 10:09:29'),(10,'Events & Campaigns','events-campaigns','Public outreach events, awareness campaigns, and metro milestones.','2026-05-13 10:09:29','2026-05-13 10:09:29');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_post`
--

DROP TABLE IF EXISTS `category_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category_post` (
  `category_id` bigint unsigned NOT NULL,
  `post_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`category_id`,`post_id`),
  KEY `category_post_post_id_foreign` (`post_id`),
  CONSTRAINT `category_post_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `category_post_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_post`
--

LOCK TABLES `category_post` WRITE;
/*!40000 ALTER TABLE `category_post` DISABLE KEYS */;
/*!40000 ALTER TABLE `category_post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint unsigned NOT NULL,
  `author_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `comments_post_id_index` (`post_id`),
  KEY `comments_status_index` (`status`),
  CONSTRAINT `comments_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `explore_pune_places`
--

DROP TABLE IF EXISTS `explore_pune_places`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `explore_pune_places` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nearest_station` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `distance_from_station` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `distance_note` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `about` text COLLATE utf8mb4_unicode_ci,
  `highlights` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_maps_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `media_id` bigint unsigned DEFAULT NULL,
  `fallback_bg` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` smallint unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `explore_pune_places_media_id_foreign` (`media_id`),
  CONSTRAINT `explore_pune_places_media_id_foreign` FOREIGN KEY (`media_id`) REFERENCES `media` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `explore_pune_places`
--

LOCK TABLES `explore_pune_places` WRITE;
/*!40000 ALTER TABLE `explore_pune_places` DISABLE KEYS */;
INSERT INTO `explore_pune_places` VALUES (1,'Shreemant Dagdusheth Halwai Ganpati Temple','Famous Temple','PMR 23 — District Court','Approx. 2 km — 25 min walk / 8 min by auto','Auto rickshaw available from District Court station','One of Pune\'s most celebrated temples, dedicated to Lord Ganesha and established in 1893 by Dagdusheth Halwai. The idol is adorned with gold ornaments and attracts thousands of devotees daily. A landmark destination during Ganesh Chaturthi, featuring grand cultural celebrations.','Established 1893 | Gold-adorned idol | Ganesh Chaturthi | Cultural events','https://maps.google.com/?q=Dagdusheth+Halwai+Ganpati+Pune',134,'linear-gradient(135deg, #7c3000 0%, #b45309 100%)',1,1,'2026-05-27 05:27:42','2026-05-27 06:26:35'),(2,'Savitribai Phule Pune University','Heritage & History','PMR 19 — Savitribai Phule Pune University','At station — 5 min walk','Directly accessible from station exit','One of India\'s leading universities, known for its stunning colonial-era architecture, sprawling green campus, and rich academic legacy. Located near University Circle, the campus is surrounded by research institutes and is a landmark destination for heritage and educational tourism.','Colonial architecture | Lush green campus | Research hub | Heritage walk','https://maps.app.goo.gl/E71zut3AD7Wra8sr7',149,'linear-gradient(135deg, #064e3b 0%, #065f46 100%)',2,1,'2026-05-27 05:27:42','2026-06-17 10:44:40'),(3,'Balewadi High Street','Historic Fort & Trekking','PMR 13 — Balewadi High Street','45 min cab ride','At station — 5 min walk','Pune\'s most vibrant commercial and lifestyle street, home to a diverse mix of restaurants, cafés, bars, retail outlets, and entertainment venues. A popular destination for families, working professionals, and visitors looking for dining, shopping, and weekend leisure activities.','Restaurants & cafes | Retail outlets | Nightlife | Weekend destination','https://maps.app.goo.gl/sS17kvKm2xyUGitK8',151,'linear-gradient(135deg, #1c1917 0%, #44403c 100%)',3,1,'2026-05-27 05:27:42','2026-06-17 11:08:22'),(4,'Shree Shiv Chhatrapati Sports Complex','Temple & Heritage','PMR 10 — Shree Shiv Chhatrapati Sports Complex, Mahalunge','At station — 5 min walk','Station is located directly adjacent to the sports complex','The Shree Shiv Chhatrapati Sports Complex in Balewadi is one of Maharashtra\'s premier multi-sport facilities, built to host national and international sporting events. The complex includes stadiums, courts, and training facilities across multiple sports disciplines.','Multi-sport complex | National & international events | Maharashtra premier facility','https://maps.app.goo.gl/6f8m7sLHHFxGXYvt9',153,'linear-gradient(135deg, #3b0764 0%, #4c1d95 100%)',4,1,'2026-05-27 05:27:42','2026-06-17 11:10:00'),(5,'Shaniwar Wada - Fortification','Historical Monument','PMR 23 — District Court','Approx. 2 km — 8 min by auto','Auto rickshaw recommended from District Court station','A magnificent 18th-century fortification and the historical seat of the Peshwa rulers of the Maratha Confederacy. Built in 1732 by Peshwa Bajirao I, the palace complex is one of Pune\'s most iconic landmarks and a symbol of Maratha heritage and architecture.','Built 1732 | Peshwa heritage | Maratha history | Sound & Light Show','https://maps.google.com/?q=Shaniwar+Wada+Pune',150,'linear-gradient(135deg, #1e3a5f 0%, #2563eb 100%)',5,1,'2026-05-27 05:27:42','2026-06-17 10:45:10'),(6,'Pataleshwar Cave Temple','Wildlife & Nature','PMR 22 — Shivaji Nagar','Approx. 1.5 km — 18 min walk / 5 min by auto','Accessible by local transport','An 8th-century rock-cut temple dedicated to Lord Shiva, carved entirely from a single basalt rock on Jangali Maharaj Road. The complex features a circular Nandi mandap and ancient stone pillars, making it an important architectural and spiritual heritage site in Pune.','Walkable from Shivaji Nagar station via Jangali Maharaj Road','https://maps.app.goo.gl/pZLugvk9WERFNrAd8',138,'linear-gradient(135deg, #14532d 0%, #16a34a 100%)',6,1,'2026-05-27 05:27:42','2026-06-17 10:51:01'),(7,'Someshwar Temple','Spirituality & Wellness','PMR 16 — Baner Pashan Link Road','Approx. 3.5 km — 10 min by auto','Auto rickshaw or cab recommended from Baner Pashan Link Road station','An ancient and serene temple dedicated to Lord Shiva, located in the peaceful Someshwarwadi area of Pashan. Surrounded by natural greenery and the Mula river, the temple is a tranquil spiritual destination popular with devotees and nature lovers alike.','Ancient Shiva temple | Riverside setting | Serene atmosphere | Pashan area','https://maps.app.goo.gl/AhKYTgcwFVruYErj8',154,'linear-gradient(135deg, #451a03 0%, #92400e 100%)',7,1,'2026-05-27 05:27:42','2026-06-17 11:10:28'),(8,'Pune Okayama Friendship Garden','Gardens & Nature','PMR 22 — Deccan Gymkhana','15 min auto-rickshaw','Accessible by local transport','The Pune Okayama Friendship Garden, also known as Pu La Deshpande Garden, is a beautifully designed Japanese-inspired garden. Built to commemorate the friendship between Pune and Okayama, Japan.','Japanese-style garden | Friendship bridge | Seasonal flowers | Peaceful ambience','https://maps.google.com/?q=Pune+Okayama+Friendship+Garden',NULL,'linear-gradient(135deg, #052e16 0%, #166534 100%)',8,0,'2026-05-27 05:27:42','2026-05-27 05:48:58'),(9,'Kasba Ganpati Temple - Heritage Site','Famous Temple','PMR 23 — District Court','Approx. 1.2 km — 17 min walk / 5 min by auto','Auto rickshaw available from District Court station','One of Pune\'s oldest and most revered Ganpati temples, Kasba Ganpati is the Gramadevata (presiding deity) of Pune. The temple holds immense religious significance and is the first Manacha Ganpati — the temple of highest honour during Ganesh Chaturthi celebrations.','Gramadevata of Pune | First Manacha Ganpati | Ganesh Chaturthi | Walking distance','https://maps.google.com/?q=Kasba+Ganpati+Temple+Pune',152,'linear-gradient(135deg, #4a1942 0%, #86198f 100%)',9,1,'2026-05-27 05:27:42','2026-06-17 11:08:42'),(10,'National War Museum - Pune','Museums & Defence','PMR 23 — Shivajinagar District Court','5 min walk','Directly accessible from station exit','The National War Museum in Pune is a tribute to India\'s armed forces, displaying war memorabilia, tanks, aircraft, and weapons from various conflicts. A must-visit for history and defence enthusiasts.','War memorabilia | Tanks & aircraft | Defence history | Patriotic landmark','https://maps.google.com/?q=National+War+Museum+Pune',NULL,'linear-gradient(135deg, #1c1917 0%, #57534e 100%)',10,0,'2026-05-27 05:27:42','2026-05-27 05:49:18'),(11,'Lohagad Fort - Trekking Destination','Historic Fort & Trekking','PMR 01 — Hinjewadi Phase 3','60 min cab ride','Accessible by cab/private vehicle','Lohagad Fort is a historic hill fort near Malavli at an altitude of 3,389 feet. Famous for its scenic beauty and Maratha heritage, it was held by Shivaji Maharaj and later by Nana Fadnavis.','Hill trekking | Panoramic views | Historic Maratha fort | Monsoon greenery','https://maps.google.com/?q=Lohagad+Fort+Pune',NULL,'linear-gradient(135deg, #0f172a 0%, #334155 100%)',11,0,'2026-05-27 05:27:42','2026-05-27 05:49:47'),(12,'Chaturshringi Temple - Sacred Site','Famous Temple & Hilltop Shrine','PMR 17 — Aundh','Approx. 3 km — 10 min by auto','Auto rickshaw recommended from Aundh station','A revered hilltop temple dedicated to Goddess Chaturshrungi, the presiding deity of Pune, located on Senapati Bapat Road. The temple sits on a mountain with four peaks and requires climbing 170 steps to reach the shrine. The natural idol (swayambhu) is especially celebrated during Navratri.','Presiding deity of Pune | 170 steps | Navratri festival | Hilltop views','https://maps.google.com/?q=Chaturshringi+Temple+Pune',116,'linear-gradient(135deg, #7f1d1d 0%, #dc2626 100%)',12,1,'2026-05-27 05:27:42','2026-05-27 06:25:54'),(13,'Saras Baug Garden - Ganesh Temple','Gardens & Temples','PMR 22 — Deccan Gymkhana','20 min auto-rickshaw','Accessible by local transport','Saras Baug is a beautiful garden in Pune, known for its Prasanna Ganapati temple, a serene lake, and lush greenery. A popular recreational spot for families and devotees alike.','Prasanna Ganapati temple | Scenic lake | Lush gardens | Family picnic spot','https://maps.google.com/?q=Saras+Baug+Pune',NULL,'linear-gradient(135deg, #1e1b4b 0%, #4338ca 100%)',13,0,'2026-05-27 05:27:42','2026-05-27 05:50:20'),(14,'Empress Botanical Garden','Gardens & Nature','PMR 22 — Deccan Gymkhana','10 min walk','Short walk from station exit','The Empress Botanical Garden is a 39-acre botanical garden in Pune established in 1881. Home to a rich variety of trees, plants, and exotic species, it is a green oasis in the heart of the city.','Exotic plant collection | 39-acre green space | Heritage botanical garden | Family park','https://maps.google.com/?q=Empress+Botanical+Garden+Pune',NULL,'linear-gradient(135deg, #134e4a 0%, #0d9488 100%)',14,0,'2026-05-27 05:27:42','2026-05-27 06:01:09'),(15,'Vishrambaug Wada - Peshwa Palace','Heritage & History','PMR 23 — Shivajinagar District Court','10 min walk','Short walk from station exit','Vishrambaug Wada is a historic Peshwa palace in Pune, known for its exquisite wooden carvings and Peshwa-era architecture. Built in 1807 by Peshwa Baji Rao II, it is now a heritage site under the Archaeological Survey of India.','Peshwa-era architecture | Wooden carvings | Heritage palace | Cultural significance','https://maps.google.com/?q=Vishrambaug+Wada+Pune',NULL,'linear-gradient(135deg, #431407 0%, #c2410c 100%)',15,0,'2026-05-27 05:27:42','2026-05-27 06:01:25'),(16,'Bund Garden - River Park','Parks & Recreation','PMR 21 — Aundh','25 min auto-rickshaw','Accessible by local transport','Bund Garden is a charming riverside park in Pune along the Mula-Mutha River. A popular recreational destination featuring lush lawns, boating facilities, and a pleasant riverside ambience.','Riverside park | Boating facilities | Lush lawns | Picnic destination','https://maps.google.com/?q=Bund+Garden+Pune',NULL,'linear-gradient(135deg, #042f2e 0%, #0f766e 100%)',16,0,'2026-05-27 05:27:42','2026-05-27 06:01:33'),(17,'Pune Railway Station - Heritage','Heritage & Transport','PMR 23 — Shivajinagar District Court','15 min walk','Short walk from station exit','Pune Railway Station, formally known as Pune Junction, is a historic railway station and one of the busiest in Maharashtra. Its classic colonial architecture and strategic location make it a landmark of Pune.','Colonial architecture | Busy transit hub | Heritage building | City gateway','https://maps.google.com/?q=Pune+Railway+Station',NULL,'linear-gradient(135deg, #1e3a5f 0%, #0369a1 100%)',17,0,'2026-05-27 05:27:42','2026-05-27 06:12:34'),(18,'Taljai Hill - Nature Reserve','Nature Reserve & Trekking','PMR 22 — Deccan Gymkhana','30 min auto-rickshaw','Accessible by local transport','Taljai Hill is a nature reserve and forest area in Pune, offering scenic trekking trails and a peaceful environment away from the city\'s bustle. Home to diverse flora and fauna, it is a nature lover\'s paradise.','Nature trails | Panoramic city views | Biodiversity | Morning walks','https://maps.google.com/?q=Taljai+Hill+Pune',NULL,'linear-gradient(135deg, #14532d 0%, #4ade80 100%)',18,0,'2026-05-27 05:27:42','2026-05-27 06:12:25'),(19,'Phursungi Village - Rural Charm','Rural & Cultural','PMR 01 — Hinjewadi Phase 3','45 min cab ride','Accessible by cab/private vehicle','Phursungi Village offers a glimpse into the rural heritage of Pune, with traditional architecture, local festivals, and agrarian culture. It represents the cultural roots of the region amidst the growing urban landscape.','Rural heritage | Traditional culture | Local festivals | Agrarian landscape','https://maps.google.com/?q=Phursungi+Pune',NULL,'linear-gradient(135deg, #422006 0%, #d97706 100%)',19,0,'2026-05-27 05:27:42','2026-05-27 06:12:17'),(20,'Khadakwasla Dam - Scenic Reservoir','Lakes & Reservoirs','PMR 01 — Hinjewadi Phase 3','50 min cab ride','Accessible by cab/private vehicle','Khadakwasla Dam is a scenic reservoir located near Pune, known for its picturesque surroundings and stunning views of the Sahyadri hills. It is one of the main water sources for Pune and a popular picnic destination.','Scenic reservoir | Sahyadri backdrop | Picnic destination | Water sports','https://maps.google.com/?q=Khadakwasla+Dam+Pune',NULL,'linear-gradient(135deg, #0c4a6e 0%, #0ea5e9 100%)',20,0,'2026-05-27 05:27:42','2026-05-27 05:44:23'),(21,'Raja Dinkar Kelkar Museum','Historical Museum','PMR 23 — District Court','Approx. 3.5 km — 10 min by auto','Auto rickshaw or cab recommended from District Court Metro Station','The Raja Dinkar Kelkar Museum is in Pune, Maharashtra, India. It contains the collection of Dr. Dinkar G. Kelkar, dedicated to the memory of his only son, Raja. The three-storey building houses various sculptures dating back to the 14th century.','Unique Private Museums | Diverse Cultural Collections | Exquisite Decorative Arts | Collection of Artefacts','https://maps.app.goo.gl/HnZiGkMrnZJhF1qa6',140,NULL,21,1,'2026-06-11 10:47:43','2026-06-11 10:51:45'),(22,'Marunji Hills','Scenic Trekking Destination','PMR 2 — Maan- MIDC Circle, Phase II','Approx. 8.2 km — 19 min by auto','Auto rickshaw or cab recommended from Maan- MIDC Circle, Phase II Metro Station','Marunji Hills is a hidden trekking and nature destination near Hinjewadi, offering panoramic views, breathtaking sunrises, and a serene green escape amidst Pune\'s rapidly growing IT corridor.','Scenic Trekking Destination | Eco-Tourism Destination | Sunrise and Sunset Point | Fitness and Outdoor Recreation Hub','https://maps.app.goo.gl/QMRxRL4PLzeXrAsr6',143,NULL,22,1,'2026-06-11 10:53:29','2026-06-11 11:40:27'),(23,'R. K. Laxman Museum','Historical Museum','PMR 12— R K Laxman Museum Balewadi','Approx. 5.3 km — 13 min by auto','Auto rickshaw or cab recommended from  R K Laxman Museum Balewadi Metro Station','The R. K. Laxman Museum offers an immersive journey through the life and works of India\'s legendary cartoonist, celebrating the timeless legacy of \'The Common Man\' through art, storytelling, and interactive exhibits','Home of the Iconic \"Common Man\" | Cultural and Educational Hub | Interactive Audio-Visual Galleries | Architecturally Distinctive Landmark | Extensive Collection of Original Works','https://maps.app.goo.gl/kAGD6iMoEmXF7scP8',142,NULL,23,1,'2026-06-11 10:56:02','2026-06-11 10:57:41');
/*!40000 ALTER TABLE `explore_pune_places` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gallery_album_images`
--

DROP TABLE IF EXISTS `gallery_album_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gallery_album_images` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `gallery_album_id` bigint unsigned NOT NULL,
  `media_id` bigint unsigned NOT NULL,
  `thumb_media_id` bigint unsigned DEFAULT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `gallery_album_images_media_id_foreign` (`media_id`),
  KEY `gallery_album_images_thumb_media_id_foreign` (`thumb_media_id`),
  KEY `gallery_album_images_gallery_album_id_sort_order_index` (`gallery_album_id`,`sort_order`),
  CONSTRAINT `gallery_album_images_gallery_album_id_foreign` FOREIGN KEY (`gallery_album_id`) REFERENCES `gallery_albums` (`id`) ON DELETE CASCADE,
  CONSTRAINT `gallery_album_images_media_id_foreign` FOREIGN KEY (`media_id`) REFERENCES `media` (`id`) ON DELETE CASCADE,
  CONSTRAINT `gallery_album_images_thumb_media_id_foreign` FOREIGN KEY (`thumb_media_id`) REFERENCES `media` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gallery_album_images`
--

LOCK TABLES `gallery_album_images` WRITE;
/*!40000 ALTER TABLE `gallery_album_images` DISABLE KEYS */;
INSERT INTO `gallery_album_images` VALUES (2,2,12,5,1,'2026-05-13 10:49:43','2026-05-13 10:49:43'),(3,2,11,7,2,'2026-05-13 10:50:31','2026-05-13 10:50:31'),(4,2,3,8,3,'2026-05-13 10:51:43','2026-05-13 10:51:43'),(5,2,4,4,4,'2026-05-13 10:52:38','2026-05-13 10:52:38'),(6,2,6,13,5,'2026-05-13 10:53:17','2026-05-13 10:53:17'),(7,2,17,16,6,'2026-05-13 10:54:33','2026-05-13 10:54:33'),(8,2,14,15,7,'2026-05-13 10:56:06','2026-05-13 10:56:06'),(9,2,14,16,8,'2026-05-13 10:57:02','2026-05-13 10:57:02'),(10,3,20,28,1,'2026-05-13 10:58:37','2026-05-13 10:58:37'),(11,3,21,29,2,'2026-05-13 10:58:54','2026-05-13 10:58:54'),(12,3,22,30,3,'2026-05-13 10:59:08','2026-05-13 10:59:08'),(13,3,23,31,4,'2026-05-13 10:59:37','2026-05-13 10:59:37'),(15,3,37,37,6,'2026-05-13 11:01:08','2026-05-13 11:30:45'),(16,3,27,34,7,'2026-05-13 11:01:34','2026-05-13 11:01:34'),(17,3,19,35,8,'2026-05-13 11:01:52','2026-05-13 11:01:52'),(18,4,58,NULL,0,'2026-05-16 13:00:18','2026-06-17 08:47:27'),(19,4,50,NULL,1,'2026-05-16 13:00:18','2026-06-17 08:47:27'),(20,4,51,NULL,4,'2026-05-16 13:00:18','2026-06-17 08:47:27'),(21,4,52,NULL,5,'2026-05-16 13:00:18','2026-06-17 08:47:27'),(25,4,56,NULL,6,'2026-05-16 13:00:18','2026-06-17 08:47:27'),(28,4,60,NULL,7,'2026-05-16 13:00:18','2026-06-17 08:47:27'),(29,4,59,NULL,8,'2026-05-16 13:00:18','2026-06-17 08:47:27'),(31,5,64,NULL,2,'2026-05-18 10:45:20','2026-05-18 10:45:20'),(35,6,72,NULL,2,'2026-05-18 10:50:38','2026-05-18 10:50:38'),(42,7,78,NULL,1,'2026-05-18 10:54:29','2026-05-18 10:54:29'),(44,7,77,NULL,3,'2026-05-18 10:54:29','2026-05-18 10:54:29'),(46,7,81,NULL,5,'2026-05-18 10:54:29','2026-05-18 10:54:29'),(47,7,80,NULL,6,'2026-05-18 10:54:29','2026-05-18 10:54:29'),(50,5,84,NULL,3,'2026-05-19 10:42:13','2026-05-19 10:42:13'),(51,5,83,NULL,4,'2026-05-19 10:42:13','2026-05-19 10:42:13'),(52,6,85,NULL,3,'2026-05-19 11:00:20','2026-05-19 11:00:20'),(54,3,101,NULL,9,'2026-05-20 06:15:40','2026-05-20 06:15:40'),(56,5,106,NULL,5,'2026-05-20 06:20:01','2026-05-20 06:20:01'),(57,5,102,NULL,6,'2026-05-20 06:20:13','2026-05-20 06:20:13'),(59,5,104,NULL,7,'2026-05-20 06:20:29','2026-05-20 06:20:29'),(61,5,109,NULL,8,'2026-05-20 06:24:30','2026-05-20 06:24:30'),(62,5,110,NULL,9,'2026-05-20 06:24:35','2026-05-20 06:24:35'),(63,6,115,NULL,6,'2026-05-20 07:47:02','2026-05-20 07:47:02'),(64,6,114,NULL,7,'2026-05-20 07:47:17','2026-05-20 07:47:17'),(65,4,148,NULL,9,'2026-06-17 08:45:01','2026-06-17 08:47:27'),(66,4,147,NULL,3,'2026-06-17 08:45:10','2026-06-17 08:47:27'),(67,4,146,NULL,2,'2026-06-17 08:45:22','2026-06-17 08:47:27');
/*!40000 ALTER TABLE `gallery_album_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gallery_albums`
--

DROP TABLE IF EXISTS `gallery_albums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gallery_albums` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `gallery_albums_slug_unique` (`slug`),
  KEY `gallery_albums_sort_order_index` (`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gallery_albums`
--

LOCK TABLES `gallery_albums` WRITE;
/*!40000 ALTER TABLE `gallery_albums` DISABLE KEYS */;
INSERT INTO `gallery_albums` VALUES (2,'CEO Leads Median Tree Plantation Drive with Embassy Quadron',NULL,'Mr. Anil Kumar Saini, CEO, PITCMRL, spearheaded a Median Tree Plantation Drive in association with Embassy Quadron reinforcing the vision of a city that’s not just well-connected, but environmentally conscious.',2,1,'2026-05-13 10:12:06','2026-05-13 11:25:57'),(3,'PITCMRL Team Donates Blood & Plants Saplings at OCC Building',NULL,'Our team at PITCMRL, OCC Building came together to donate blood and plant saplings because one act gives someone a second chance at life, and the other gives the city a breath of fresh air.',3,1,'2026-05-13 10:12:20','2026-05-13 10:14:59'),(4,'Project Update','project-update',NULL,4,1,'2026-05-16 12:59:33','2026-05-16 13:00:04'),(5,'Tata Power Solar: Energising Pune Metro Line 3',NULL,'Sustainably\nClean energy. Smarter stations. A more sustainable Pune',5,1,'2026-05-18 10:44:32','2026-05-19 10:36:03'),(6,'Laying the Foundation the Right Way at OCC Building, Hinjewadi',NULL,'Blessings for the Journey Ahead - Pooja at Maan Depot',6,1,'2026-05-18 10:47:20','2026-05-19 10:35:00'),(7,'Republic Day Celebrations at PITCMRL OCC Building',NULL,'Pride in Every Salute. Republic Day at PITCMRL OCC Building',7,1,'2026-05-18 10:52:25','2026-05-18 11:19:06');
/*!40000 ALTER TABLE `gallery_albums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marquee_items`
--

DROP TABLE IF EXISTS `marquee_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marquee_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `text` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `marquee_items_sort_order_index` (`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marquee_items`
--

LOCK TABLES `marquee_items` WRITE;
/*!40000 ALTER TABLE `marquee_items` DISABLE KEYS */;
INSERT INTO `marquee_items` VALUES (1,'Experience the Future of Urban Mobility with Pune Metro',0,1,'2026-05-29 18:27:38','2026-05-29 18:27:38'),(2,'Your Journey, Simplified',1,1,'2026-05-29 18:27:38','2026-05-29 18:27:38'),(3,'Redefining City Travel with Speed, Safety & Comfort',2,1,'2026-05-29 18:27:38','2026-05-29 18:27:38'),(4,'Pune Metro Line 3 — Hinjewadi to Shivajinagar',3,1,'2026-05-29 18:27:38','2026-05-29 18:27:38'),(5,'Safe · Fast · Sustainable',4,1,'2026-05-29 18:27:38','2026-05-29 18:27:38'),(6,'Connect. Commute. Celebrate Pune.',5,1,'2026-05-29 18:27:38','2026-05-29 18:27:38');
/*!40000 ALTER TABLE `marquee_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` bigint unsigned NOT NULL,
  `uploaded_by` bigint unsigned NOT NULL,
  `module` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `media_uploaded_by_foreign` (`uploaded_by`),
  KEY `media_file_type_index` (`file_type`),
  KEY `media_created_at_index` (`created_at`),
  KEY `media_module_index` (`module`),
  CONSTRAINT `media_uploaded_by_foreign` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT INTO `media` VALUES (1,'POST-3 (3).png','media/originals/post-3-3_1778667632.png','image/png',2606392,1,'gallery','2026-05-13 10:20:32','2026-05-13 10:20:32'),(2,'image-1.png','media/originals/image-1_1778667666.png','image/png',88389,1,'gallery','2026-05-13 10:21:06','2026-05-13 10:21:06'),(3,'WhatsApp Image 2026-05-02 at 12.09.44 (1).jpeg','media/originals/whatsapp-image-2026-05-02-at-120944-1_1778668364.jpeg','image/jpeg',243222,1,NULL,'2026-05-13 10:32:44','2026-05-13 10:32:44'),(4,'WhatsApp Image 2026-05-02 at 12.09.44 (2).jpeg','media/originals/whatsapp-image-2026-05-02-at-120944-2_1778668373.jpeg','image/jpeg',214329,1,NULL,'2026-05-13 10:32:53','2026-05-13 10:32:53'),(5,'photo-1.png','media/originals/photo-1_1778668374.png','image/png',205382,1,'gallery','2026-05-13 10:32:54','2026-05-13 10:32:54'),(6,'WhatsApp Image 2026-05-02 at 12.10.20 (1).jpeg','media/originals/whatsapp-image-2026-05-02-at-121020-1_1778668387.jpeg','image/jpeg',140725,1,NULL,'2026-05-13 10:33:07','2026-05-13 10:33:07'),(7,'photo-2.png','media/originals/photo-2_1778668388.png','image/png',187936,1,'gallery','2026-05-13 10:33:08','2026-05-13 10:33:08'),(8,'photo-3.png','media/originals/photo-3_1778668396.png','image/png',215678,1,'gallery','2026-05-13 10:33:16','2026-05-13 10:33:16'),(9,'WhatsApp Image 2026-05-02 at 12.10.21 (1).jpeg','media/originals/whatsapp-image-2026-05-02-at-121021-1_1778668397.jpeg','image/jpeg',139556,1,NULL,'2026-05-13 10:33:17','2026-05-13 10:33:17'),(10,'photo-3.png','media/originals/photo-3_1778668405.png','image/png',215678,1,'gallery','2026-05-13 10:33:25','2026-05-13 10:33:25'),(11,'WhatsApp Image 2026-05-02 at 12.10.52.jpeg','media/originals/whatsapp-image-2026-05-02-at-121052_1778668406.jpeg','image/jpeg',368667,1,NULL,'2026-05-13 10:33:26','2026-05-13 10:33:26'),(12,'WhatsApp Image 2026-05-02 at 12.10.53 (2).jpeg','media/originals/whatsapp-image-2026-05-02-at-121053-2_1778668413.jpeg','image/jpeg',402327,1,NULL,'2026-05-13 10:33:33','2026-05-13 10:33:33'),(13,'photo-5.png','media/originals/photo-5_1778668413.png','image/png',205296,1,'gallery','2026-05-13 10:33:33','2026-05-13 10:33:33'),(14,'WhatsApp Image 2026-05-02 at 12.10.54 (1).jpeg','media/originals/whatsapp-image-2026-05-02-at-121054-1_1778668420.jpeg','image/jpeg',449817,1,NULL,'2026-05-13 10:33:40','2026-05-13 10:33:40'),(15,'photo-6.png','media/originals/photo-6_1778668420.png','image/png',221776,1,'gallery','2026-05-13 10:33:40','2026-05-13 10:33:40'),(16,'photo-7.png','media/originals/photo-7_1778668431.png','image/png',216639,1,'gallery','2026-05-13 10:33:51','2026-05-13 10:33:51'),(17,'WhatsApp Image 2026-05-02 at 12.10.54.jpeg','media/originals/whatsapp-image-2026-05-02-at-121054_1778668438.jpeg','image/jpeg',447958,1,NULL,'2026-05-13 10:33:58','2026-05-13 10:33:58'),(18,'photo-8.png','media/originals/photo-8_1778668444.png','image/png',216987,1,'gallery','2026-05-13 10:34:04','2026-05-13 10:34:04'),(19,'WhatsApp Image 2026-04-30 at 12.08.09 (1).jpeg','media/originals/whatsapp-image-2026-04-30-at-120809-1_1778668824.jpeg','image/jpeg',2736554,1,NULL,'2026-05-13 10:40:24','2026-05-13 10:40:24'),(20,'WhatsApp Image 2026-04-30 at 17.01.54 (2).jpeg','media/originals/whatsapp-image-2026-04-30-at-170154-2_1778668831.jpeg','image/jpeg',236611,1,NULL,'2026-05-13 10:40:31','2026-05-13 10:40:31'),(21,'WhatsApp Image 2026-04-30 at 17.01.54.jpeg','media/originals/whatsapp-image-2026-04-30-at-170154_1778668839.jpeg','image/jpeg',2473229,1,NULL,'2026-05-13 10:40:39','2026-05-13 10:40:39'),(22,'WhatsApp Image 2026-04-30 at 17.01.55 (1).jpeg','media/originals/whatsapp-image-2026-04-30-at-170155-1_1778668863.jpeg','image/jpeg',162260,1,'gallery','2026-05-13 10:41:03','2026-05-13 10:41:03'),(23,'WhatsApp Image 2026-04-30 at 17.01.55 (2).jpeg','media/originals/whatsapp-image-2026-04-30-at-170155-2_1778668877.jpeg','image/jpeg',142166,1,'gallery','2026-05-13 10:41:17','2026-05-13 10:41:17'),(24,'WhatsApp Image 2026-04-30 at 17.01.55 (2).jpeg','media/originals/whatsapp-image-2026-04-30-at-170155-2_1778668887.jpeg','image/jpeg',142166,1,'gallery','2026-05-13 10:41:27','2026-05-13 10:41:27'),(25,'WhatsApp Image 2026-04-30 at 17.01.55.jpeg','media/originals/whatsapp-image-2026-04-30-at-170155_1778668898.jpeg','image/jpeg',266404,1,'gallery','2026-05-13 10:41:38','2026-05-13 10:41:38'),(26,'WhatsApp Image 2026-04-30 at 17.01.56 (1).jpeg','media/originals/whatsapp-image-2026-04-30-at-170156-1_1778668906.jpeg','image/jpeg',97318,1,'gallery','2026-05-13 10:41:46','2026-05-13 10:41:46'),(27,'WhatsApp Image 2026-04-30 at 17.01.56.jpeg','media/originals/whatsapp-image-2026-04-30-at-170156_1778668914.jpeg','image/jpeg',116358,1,'gallery','2026-05-13 10:41:54','2026-05-13 10:41:54'),(28,'photo-1.png','media/originals/photo-1_1778669208.png','image/png',174425,1,'gallery','2026-05-13 10:46:48','2026-05-13 10:46:48'),(29,'photo-2.png','media/originals/photo-2_1778669208.png','image/png',195507,1,'gallery','2026-05-13 10:46:48','2026-05-13 10:46:48'),(30,'photo-3.png','media/originals/photo-3_1778669208.png','image/png',155153,1,'gallery','2026-05-13 10:46:48','2026-05-13 10:46:48'),(31,'photo-4.png','media/originals/photo-4_1778669208.png','image/png',158112,1,'gallery','2026-05-13 10:46:48','2026-05-13 10:46:48'),(32,'photo-5.png','media/originals/photo-5_1778669208.png','image/png',166473,1,'gallery','2026-05-13 10:46:48','2026-05-13 10:46:48'),(33,'photo-6.png','media/originals/photo-6_1778669208.png','image/png',138819,1,'gallery','2026-05-13 10:46:48','2026-05-13 10:46:48'),(34,'photo-7.png','media/originals/photo-7_1778669209.png','image/png',131422,1,'gallery','2026-05-13 10:46:49','2026-05-13 10:46:49'),(35,'photo-8.png','media/originals/photo-8_1778669209.png','image/png',205931,1,'gallery','2026-05-13 10:46:49','2026-05-13 10:46:49'),(36,'WhatsApp Image 2026-04-30 at 12.08.11.jpeg','media/originals/whatsapp-image-2026-04-30-at-120811_1778671660.jpeg','image/jpeg',2750393,1,NULL,'2026-05-13 11:27:40','2026-05-13 11:27:40'),(37,'WhatsApp Image 2026-04-30 at 12.08.10.jpeg','media/originals/whatsapp-image-2026-04-30-at-120810_1778671792.jpeg','image/jpeg',2464090,1,NULL,'2026-05-13 11:29:52','2026-05-13 11:29:52'),(38,'construction-1.png','media/originals/construction-1_1778936389.png','image/png',171846,1,'project-update','2026-05-16 12:59:49','2026-05-16 12:59:49'),(39,'construction-2.png','media/originals/construction-2_1778936389.png','image/png',149171,1,'project-update','2026-05-16 12:59:49','2026-05-16 12:59:49'),(40,'construction-3.png','media/originals/construction-3_1778936389.png','image/png',208748,1,'project-update','2026-05-16 12:59:49','2026-05-16 12:59:49'),(41,'construction-4.png','media/originals/construction-4_1778936390.png','image/png',162121,1,'project-update','2026-05-16 12:59:50','2026-05-16 12:59:50'),(42,'construction-5.png','media/originals/construction-5_1778936390.png','image/png',171211,1,'project-update','2026-05-16 12:59:50','2026-05-16 12:59:50'),(43,'construction-6.png','media/originals/construction-6_1778936390.png','image/png',177279,1,'project-update','2026-05-16 12:59:50','2026-05-16 12:59:50'),(44,'construction-7.png','media/originals/construction-7_1778936391.png','image/png',160912,1,'project-update','2026-05-16 12:59:51','2026-05-16 12:59:51'),(45,'construction-8.png','media/originals/construction-8_1778936391.png','image/png',165335,1,'project-update','2026-05-16 12:59:51','2026-05-16 12:59:51'),(46,'construction-9.png','media/originals/construction-9_1778936391.png','image/png',169116,1,'project-update','2026-05-16 12:59:51','2026-05-16 12:59:51'),(47,'construction-10.png','media/originals/construction-10_1778936392.png','image/png',201526,1,'project-update','2026-05-16 12:59:52','2026-05-16 12:59:52'),(48,'construction-11.png','media/originals/construction-11_1778936392.png','image/png',145273,1,'project-update','2026-05-16 12:59:52','2026-05-16 12:59:52'),(49,'construction-12.png','media/originals/construction-12_1778936392.png','image/png',172626,1,'project-update','2026-05-16 12:59:52','2026-05-16 12:59:52'),(50,'Mask group (1).png','media/originals/mask-group-1_1779099889.png','image/png',155908,1,NULL,'2026-05-18 10:24:49','2026-05-18 10:24:49'),(51,'Mask group (2).png','media/originals/mask-group-2_1779099889.png','image/png',137716,1,NULL,'2026-05-18 10:24:49','2026-05-18 10:24:49'),(52,'Mask group (3).png','media/originals/mask-group-3_1779099889.png','image/png',124605,1,NULL,'2026-05-18 10:24:49','2026-05-18 10:24:49'),(53,'Mask group (4).png','media/originals/mask-group-4_1779099889.png','image/png',149171,1,NULL,'2026-05-18 10:24:49','2026-05-18 10:24:49'),(54,'Mask group (5).png','media/originals/mask-group-5_1779099889.png','image/png',165335,1,NULL,'2026-05-18 10:24:49','2026-05-18 10:24:49'),(55,'Mask group (6).png','media/originals/mask-group-6_1779099889.png','image/png',171211,1,NULL,'2026-05-18 10:24:49','2026-05-18 10:24:49'),(56,'Mask group (7).png','media/originals/mask-group-7_1779099889.png','image/png',201526,1,NULL,'2026-05-18 10:24:49','2026-05-18 10:24:49'),(57,'Mask group (8).png','media/originals/mask-group-8_1779099889.png','image/png',163487,1,NULL,'2026-05-18 10:24:49','2026-05-18 10:24:49'),(58,'Mask group.png','media/originals/mask-group_1779099889.png','image/png',161203,1,NULL,'2026-05-18 10:24:49','2026-05-18 10:24:49'),(59,'Mask group (11).png','media/originals/mask-group-11_1779099890.png','image/png',137283,1,NULL,'2026-05-18 10:24:50','2026-05-18 10:24:50'),(60,'Mask group (10).png','media/originals/mask-group-10_1779099890.png','image/png',146564,1,NULL,'2026-05-18 10:24:50','2026-05-18 10:24:50'),(61,'Mask group (9).png','media/originals/mask-group-9_1779099890.png','image/png',145273,1,NULL,'2026-05-18 10:24:50','2026-05-18 10:24:50'),(62,'IMG_20260225_113740.jpg','media/originals/img-20260225-113740_1779101097.jpg','image/jpeg',3803253,1,NULL,'2026-05-18 10:44:57','2026-05-18 10:44:57'),(63,'IMG_20260225_113823.jpg','media/originals/img-20260225-113823_1779101097.jpg','image/jpeg',4135713,1,NULL,'2026-05-18 10:44:57','2026-05-18 10:44:57'),(64,'IMG-20260225-WA0011.jpg','media/originals/img-20260225-wa0011_1779101097.jpg','image/jpeg',174882,1,NULL,'2026-05-18 10:44:57','2026-05-18 10:44:57'),(65,'IMG-20260225-WA0012.jpg','media/originals/img-20260225-wa0012_1779101098.jpg','image/jpeg',181611,1,NULL,'2026-05-18 10:44:58','2026-05-18 10:44:58'),(66,'IMG_20250922_095439.jpg','media/originals/img-20250922-095439_1779101408.jpg','image/jpeg',879921,1,NULL,'2026-05-18 10:50:08','2026-05-18 10:50:08'),(67,'IMG_20250922_095449_1.jpg','media/originals/img-20250922-095449-1_1779101408.jpg','image/jpeg',847451,1,NULL,'2026-05-18 10:50:08','2026-05-18 10:50:08'),(68,'IMG_20250922_095529.jpg','media/originals/img-20250922-095529_1779101409.jpg','image/jpeg',2801510,1,NULL,'2026-05-18 10:50:09','2026-05-18 10:50:09'),(69,'IMG_20250922_095957.jpg','media/originals/img-20250922-095957_1779101409.jpg','image/jpeg',831567,1,NULL,'2026-05-18 10:50:09','2026-05-18 10:50:09'),(70,'IMG_20250922_102339.jpg','media/originals/img-20250922-102339_1779101410.jpg','image/jpeg',3283697,1,NULL,'2026-05-18 10:50:10','2026-05-18 10:50:10'),(71,'IMG_20250922_102339 (1).jpg','media/originals/img-20250922-102339-1_1779101410.jpg','image/jpeg',3283697,1,NULL,'2026-05-18 10:50:10','2026-05-18 10:50:10'),(72,'IMG_20250922_102250.jpg','media/originals/img-20250922-102250_1779101411.jpg','image/jpeg',3264148,1,NULL,'2026-05-18 10:50:11','2026-05-18 10:50:11'),(73,'IMG_20250922_101941.jpg','media/originals/img-20250922-101941_1779101411.jpg','image/jpeg',627252,1,NULL,'2026-05-18 10:50:11','2026-05-18 10:50:11'),(74,'IMG_20250922_102358.jpg','media/originals/img-20250922-102358_1779101504.jpg','image/jpeg',3289409,1,NULL,'2026-05-18 10:51:44','2026-05-18 10:51:44'),(75,'IMG-20260126-WA0004.jpg','media/originals/img-20260126-wa0004_1779101645.jpg','image/jpeg',253965,1,NULL,'2026-05-18 10:54:05','2026-05-18 10:54:05'),(76,'IMG-20260126-WA0005.jpg','media/originals/img-20260126-wa0005_1779101645.jpg','image/jpeg',247895,1,NULL,'2026-05-18 10:54:05','2026-05-18 10:54:05'),(77,'IMG-20260126-WA0019.jpg','media/originals/img-20260126-wa0019_1779101645.jpg','image/jpeg',1407619,1,NULL,'2026-05-18 10:54:05','2026-05-18 10:54:05'),(78,'IMG-20260126-WA0020.jpg','media/originals/img-20260126-wa0020_1779101645.jpg','image/jpeg',1323729,1,NULL,'2026-05-18 10:54:05','2026-05-18 10:54:05'),(79,'IMG-20260126-WA0024.jpg','media/originals/img-20260126-wa0024_1779101646.jpg','image/jpeg',1244999,1,NULL,'2026-05-18 10:54:06','2026-05-18 10:54:06'),(80,'IMG-20260126-WA0032.jpg','media/originals/img-20260126-wa0032_1779101646.jpg','image/jpeg',554730,1,NULL,'2026-05-18 10:54:06','2026-05-18 10:54:06'),(81,'IMG-20260126-WA0037.jpg','media/originals/img-20260126-wa0037_1779101646.jpg','image/jpeg',1298699,1,NULL,'2026-05-18 10:54:06','2026-05-18 10:54:06'),(82,'IMG-20260126-WA0038.jpg','media/originals/img-20260126-wa0038_1779101646.jpg','image/jpeg',1350518,1,NULL,'2026-05-18 10:54:06','2026-05-18 10:54:06'),(83,'WhatsApp Image 2026-05-19 at 12.51.08 (1).jpeg','media/originals/whatsapp-image-2026-05-19-at-125108-1_1779187310.jpeg','image/jpeg',85281,1,NULL,'2026-05-19 10:41:50','2026-05-19 10:41:50'),(84,'WhatsApp Image 2026-05-19 at 12.51.10 (2).jpeg','media/originals/whatsapp-image-2026-05-19-at-125110-2_1779187310.jpeg','image/jpeg',151629,1,NULL,'2026-05-19 10:41:50','2026-05-19 10:41:50'),(85,'WhatsApp Image 2026-04-29 at 15.20.27.jpeg','media/originals/whatsapp-image-2026-04-29-at-152027_1779188408.jpeg','image/jpeg',132208,1,NULL,'2026-05-19 11:00:08','2026-05-19 11:00:08'),(86,'WhatsApp Image 2026-05-19 at 12.51.54 (2).jpeg','media/originals/whatsapp-image-2026-05-19-at-125154-2_1779188409.jpeg','image/jpeg',128232,1,NULL,'2026-05-19 11:00:09','2026-05-19 11:00:09'),(87,'ms-k-manjulekshmi.png','media/originals/ms-k-manjulekshmi_1779191115.png','image/png',69028,1,'board','2026-05-19 11:45:15','2026-05-19 11:45:15'),(88,'mr-rajan-kapoor.png','media/originals/mr-rajan-kapoor_1779191115.png','image/png',61136,1,'board','2026-05-19 11:45:15','2026-05-19 11:45:15'),(89,'mr-sudip-mullick.png','media/originals/mr-sudip-mullick_1779191115.png','image/png',45935,1,'board','2026-05-19 11:45:15','2026-05-19 11:45:15'),(90,'ms-anjali-gupta.png','media/originals/ms-anjali-gupta_1779191115.png','image/png',61655,1,'board','2026-05-19 11:45:15','2026-05-19 11:45:15'),(91,'dr-mangu-singh.png','media/originals/dr-mangu-singh_1779191116.png','image/png',46954,1,'board','2026-05-19 11:45:16','2026-05-19 11:45:16'),(92,'dr-praveer-sinha.png','media/originals/dr-praveer-sinha_1779191116.png','image/png',47389,1,'board','2026-05-19 11:45:16','2026-05-19 11:45:16'),(93,'mr-basil-watters.png','media/originals/mr-basil-watters_1779191116.png','image/png',49827,1,'board','2026-05-19 11:45:16','2026-05-19 11:45:16'),(94,'mr-deepak-singla.png','media/originals/mr-deepak-singla_1779191116.png','image/png',56802,1,'board','2026-05-19 11:45:16','2026-05-19 11:45:16'),(95,'ms-sukriti-sood.png','media/originals/ms-sukriti-sood_1779191116.png','image/png',55935,1,'board','2026-05-19 11:45:16','2026-05-19 11:45:16'),(96,'ceo-photo.png','media/originals/ceo-photo_1779191116.png','image/png',1970648,1,'board','2026-05-19 11:45:16','2026-05-19 11:45:16'),(97,'mithul.png','media/originals/mithul_1779191721.png','image/png',156995,1,'board','2026-05-19 11:55:21','2026-05-19 11:55:21'),(98,'WhatsApp Image 2026-05-19 at 12.51.08 (2).jpeg','media/originals/whatsapp-image-2026-05-19-at-125108-2_1779257586.jpeg','image/jpeg',100720,1,NULL,'2026-05-20 06:13:06','2026-05-20 06:13:06'),(99,'WhatsApp Image 2026-05-19 at 12.51.09 (2).jpeg','media/originals/whatsapp-image-2026-05-19-at-125109-2_1779257586.jpeg','image/jpeg',71385,1,NULL,'2026-05-20 06:13:06','2026-05-20 06:13:06'),(100,'WhatsApp Image 2026-05-19 at 12.51.11 (1) (1).jpeg','media/originals/whatsapp-image-2026-05-19-at-125111-1-1_1779257586.jpeg','image/jpeg',153229,1,NULL,'2026-05-20 06:13:06','2026-05-20 06:13:06'),(101,'WhatsApp Image 2026-04-30 at 12.08.12 (3).jpeg','media/originals/whatsapp-image-2026-04-30-at-120812-3_1779257720.jpeg','image/jpeg',3091582,1,NULL,'2026-05-20 06:15:20','2026-05-20 06:15:20'),(102,'Screenshot 2026-05-20 at 11.47.47 AM.png','media/originals/screenshot-2026-05-20-at-114747-am_1779257932.png','image/png',1103191,1,NULL,'2026-05-20 06:18:52','2026-05-20 06:18:52'),(103,'WhatsApp Image 2026-05-19 at 12.51.08 (1) (1).jpeg','media/originals/whatsapp-image-2026-05-19-at-125108-1-1_1779257985.jpeg','image/jpeg',85281,1,NULL,'2026-05-20 06:19:45','2026-05-20 06:19:45'),(104,'WhatsApp Image 2026-05-19 at 12.51.08 (2).jpeg','media/originals/whatsapp-image-2026-05-19-at-125108-2_1779257985.jpeg','image/jpeg',100720,1,NULL,'2026-05-20 06:19:45','2026-05-20 06:19:45'),(105,'WhatsApp Image 2026-05-19 at 12.51.09 (2).jpeg','media/originals/whatsapp-image-2026-05-19-at-125109-2_1779257985.jpeg','image/jpeg',71385,1,NULL,'2026-05-20 06:19:45','2026-05-20 06:19:45'),(106,'WhatsApp Image 2026-05-19 at 12.51.10 (3).jpeg','media/originals/whatsapp-image-2026-05-19-at-125110-3_1779257986.jpeg','image/jpeg',165258,1,NULL,'2026-05-20 06:19:46','2026-05-20 06:19:46'),(107,'WhatsApp Image 2026-04-29 at 15.20.26 (4) (1).jpeg','media/originals/whatsapp-image-2026-04-29-at-152026-4-1_1779258113.jpeg','image/jpeg',238015,1,NULL,'2026-05-20 06:21:53','2026-05-20 06:21:53'),(108,'WhatsApp Image 2026-04-29 at 15.20.27 (3).jpeg','media/originals/whatsapp-image-2026-04-29-at-152027-3_1779258113.jpeg','image/jpeg',132208,1,NULL,'2026-05-20 06:21:53','2026-05-20 06:21:53'),(109,'WhatsApp Image 2026-05-19 at 12.51.13 (1) (1).jpeg','media/originals/whatsapp-image-2026-05-19-at-125113-1-1_1779258258.jpeg','image/jpeg',255101,1,NULL,'2026-05-20 06:24:18','2026-05-20 06:24:18'),(110,'WhatsApp Image 2026-05-19 at 12.51.11 (2).jpeg','media/originals/whatsapp-image-2026-05-19-at-125111-2_1779258258.jpeg','image/jpeg',156087,1,NULL,'2026-05-20 06:24:18','2026-05-20 06:24:18'),(111,'WhatsApp Image 2026-05-20 at 13.07.32 (1).jpeg','media/originals/whatsapp-image-2026-05-20-at-130732-1_1779263201.jpeg','image/jpeg',342176,1,NULL,'2026-05-20 07:46:41','2026-05-20 07:46:41'),(112,'WhatsApp Image 2026-05-20 at 13.07.32 (2).jpeg','media/originals/whatsapp-image-2026-05-20-at-130732-2_1779263201.jpeg','image/jpeg',350701,1,NULL,'2026-05-20 07:46:41','2026-05-20 07:46:41'),(113,'WhatsApp Image 2026-05-20 at 13.07.32.jpeg','media/originals/whatsapp-image-2026-05-20-at-130732_1779263201.jpeg','image/jpeg',342215,1,NULL,'2026-05-20 07:46:41','2026-05-20 07:46:41'),(114,'WhatsApp Image 2026-05-20 at 13.07.33.jpeg','media/originals/whatsapp-image-2026-05-20-at-130733_1779263201.jpeg','image/jpeg',65594,1,NULL,'2026-05-20 07:46:41','2026-05-20 07:46:41'),(115,'WhatsApp Image 2026-05-20 at 13.08.22.jpeg','media/originals/whatsapp-image-2026-05-20-at-130822_1779263201.jpeg','image/jpeg',123747,1,NULL,'2026-05-20 07:46:41','2026-05-20 07:46:41'),(116,'khadakwasla-dam.png','media/originals/khadakwasla-dam_1779860332.png','image/png',741000,1,'explore-pune','2026-05-27 05:38:52','2026-05-27 05:38:52'),(117,'phursungi-village.png','media/originals/phursungi-village_1779860332.png','image/png',1163499,1,'explore-pune','2026-05-27 05:38:52','2026-05-27 05:38:52'),(118,'taljai-hill.png','media/originals/taljai-hill_1779860332.png','image/png',734565,1,'explore-pune','2026-05-27 05:38:52','2026-05-27 05:38:52'),(119,'pune-railway-station.png','media/originals/pune-railway-station_1779860333.png','image/png',2462326,1,'explore-pune','2026-05-27 05:38:53','2026-05-27 05:38:53'),(120,'bund-garden.png','media/originals/bund-garden_1779860333.png','image/png',1281787,1,'explore-pune','2026-05-27 05:38:53','2026-05-27 05:38:53'),(121,'vishrambaug-wada.png','media/originals/vishrambaug-wada_1779860334.png','image/png',1594548,1,'explore-pune','2026-05-27 05:38:54','2026-05-27 05:38:54'),(122,'empress-botanical-garden.png','media/originals/empress-botanical-garden_1779860334.png','image/png',1406294,1,'explore-pune','2026-05-27 05:38:54','2026-05-27 05:38:54'),(123,'saras-baug-garden.png','media/originals/saras-baug-garden_1779860334.png','image/png',1454440,1,'explore-pune','2026-05-27 05:38:54','2026-05-27 05:38:54'),(124,'chaturshringi-temple.png','media/originals/chaturshringi-temple_1779860335.png','image/png',3649324,1,'explore-pune','2026-05-27 05:38:55','2026-05-27 05:38:55'),(125,'lohagad-fort.png','media/originals/lohagad-fort_1779860335.png','image/png',1956660,1,'explore-pune','2026-05-27 05:38:55','2026-05-27 05:38:55'),(126,'national-war-museum.png','media/originals/national-war-museum_1779860335.png','image/png',688159,1,'explore-pune','2026-05-27 05:38:55','2026-05-27 05:38:55'),(127,'kasba-ganpati-temple.png','media/originals/kasba-ganpati-temple_1779860335.png','image/png',740187,1,'explore-pune','2026-05-27 05:38:55','2026-05-27 05:38:55'),(128,'pune-okayama-garden.png','media/originals/pune-okayama-garden_1779860336.png','image/png',2965014,1,'explore-pune','2026-05-27 05:38:56','2026-05-27 05:38:56'),(129,'sinhagad-fort.png','media/originals/sinhagad-fort_1779860336.png','image/png',5086801,1,'explore-pune','2026-05-27 05:38:56','2026-05-27 05:38:56'),(130,'rajiv-gandhi-zoological-park.png','media/originals/rajiv-gandhi-zoological-park_1779860336.png','image/png',471494,1,'explore-pune','2026-05-27 05:38:56','2026-05-27 05:38:56'),(131,'shaniwar-wada.png','media/originals/shaniwar-wada_1779860337.png','image/png',1396268,1,'explore-pune','2026-05-27 05:38:57','2026-05-27 05:38:57'),(132,'parvati-hill-temple.png','media/originals/parvati-hill-temple_1779860337.png','image/png',260021,1,'explore-pune','2026-05-27 05:38:57','2026-05-27 05:38:57'),(133,'aga-khan-palace.png','media/originals/aga-khan-palace_1779860337.png','image/png',260952,1,'explore-pune','2026-05-27 05:38:57','2026-05-27 05:38:57'),(134,'dagdusheth-ganpati-temple.png','media/originals/dagdusheth-ganpati-temple_1779860337.png','image/png',262552,1,'explore-pune','2026-05-27 05:38:57','2026-05-27 05:38:57'),(135,'Group 88.png','media/originals/group-88_1779959370.png','image/png',191093,1,'explore-pune','2026-05-28 09:09:30','2026-05-28 09:09:30'),(136,'Group 89.png','media/originals/group-89_1779959850.png','image/png',344719,1,'explore-pune','2026-05-28 09:17:30','2026-05-28 09:17:30'),(137,'Group 90.png','media/originals/group-90_1779960481.png','image/png',161758,1,'explore-pune','2026-05-28 09:28:01','2026-05-28 09:28:01'),(138,'Group 91.png','media/originals/group-91_1779960761.png','image/png',305541,1,'explore-pune','2026-05-28 09:32:41','2026-05-28 09:32:41'),(139,'Group 92.png','media/originals/group-92_1779961363.png','image/png',274103,1,'explore-pune','2026-05-28 09:42:43','2026-05-28 09:42:43'),(140,'Group 93.png','media/originals/group-93_1781174883.png','image/png',247304,1,'explore-pune','2026-06-11 10:48:03','2026-06-11 10:48:03'),(141,'Group 94.png','media/originals/group-94_1781175236.png','image/png',216717,1,'explore-pune','2026-06-11 10:53:56','2026-06-11 10:53:56'),(142,'Group 95.png','media/originals/group-95_1781175378.png','image/png',247083,1,'explore-pune','2026-06-11 10:56:18','2026-06-11 10:56:18'),(143,'55e2bb46069f45cdb1becaa42c6d1859dc63e7e8_2_230x500.jpeg','media/originals/55e2bb46069f45cdb1becaa42c6d1859dc63e7e8-2-230x500_1781178022.jpeg','image/jpeg',29675,1,'explore-pune','2026-06-11 11:40:22','2026-06-11 11:40:22'),(144,'20260413_102147.jpg','media/originals/20260413-102147_1781681865.jpg','image/jpeg',6916591,1,NULL,'2026-06-17 07:37:45','2026-06-17 07:37:45'),(145,'20260413_102330.jpg','media/originals/20260413-102330_1781681866.jpg','image/jpeg',6412746,1,NULL,'2026-06-17 07:37:46','2026-06-17 07:37:46'),(146,'20260413_102932 (3).jpg','media/originals/20260413-102932-3_1781681866.jpg','image/jpeg',3230599,1,NULL,'2026-06-17 07:37:46','2026-06-17 07:37:46'),(147,'20260413_102147.jpg','media/originals/20260413-102147_1781681888.jpg','image/jpeg',6916591,1,NULL,'2026-06-17 07:38:08','2026-06-17 07:38:08'),(148,'20260413_143255.jpg','media/originals/20260413-143255_1781681988.jpg','image/jpeg',7872954,1,NULL,'2026-06-17 07:39:48','2026-06-17 07:39:48'),(149,'Savitribai Phule Pune Universit.webp','media/originals/savitribai-phule-pune-universit_1781693075.webp','image/webp',103424,1,'explore-pune','2026-06-17 10:44:35','2026-06-17 10:44:35'),(150,'Shanivar Wada.webp','media/originals/shanivar-wada_1781693108.webp','image/webp',86650,1,'explore-pune','2026-06-17 10:45:08','2026-06-17 10:45:08'),(151,'Balewadi High street.webp','media/originals/balewadi-high-street_1781694500.webp','image/webp',94048,1,'explore-pune','2026-06-17 11:08:20','2026-06-17 11:08:20'),(152,'Kasba Ganpat temple.webp','media/originals/kasba-ganpat-temple_1781694520.webp','image/webp',127254,1,'explore-pune','2026-06-17 11:08:40','2026-06-17 11:08:40'),(153,'Shri Chatrpati sports complex.webp','media/originals/shri-chatrpati-sports-complex_1781694598.webp','image/webp',102828,1,'explore-pune','2026-06-17 11:09:58','2026-06-17 11:09:58'),(154,'Someshwar temple.jpg','media/originals/someshwar-temple_1781694625.jpg','image/webp',110970,1,'explore-pune','2026-06-17 11:10:25','2026-06-17 11:10:25');
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_dimensions`
--

DROP TABLE IF EXISTS `media_dimensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_dimensions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `width` int unsigned NOT NULL,
  `height` int unsigned NOT NULL,
  `module` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `media_dimensions_module_index` (`module`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_dimensions`
--

LOCK TABLES `media_dimensions` WRITE;
/*!40000 ALTER TABLE `media_dimensions` DISABLE KEYS */;
INSERT INTO `media_dimensions` VALUES (1,'Thumbnail',200,200,NULL,'2026-05-13 10:09:44','2026-05-13 10:09:44'),(2,'Small',400,300,NULL,'2026-05-13 10:09:44','2026-05-13 10:09:44'),(3,'Medium',800,600,NULL,'2026-05-13 10:09:44','2026-05-13 10:09:44'),(4,'Large',1200,800,NULL,'2026-05-13 10:09:44','2026-05-13 10:09:44'),(5,'Wide Banner',1920,400,NULL,'2026-05-13 10:09:44','2026-05-13 10:09:44'),(6,'Blog Cover',1200,630,'blog','2026-05-13 10:09:44','2026-05-13 10:09:44'),(7,'Blog Thumbnail',400,250,'blog','2026-05-13 10:09:44','2026-05-13 10:09:44');
/*!40000 ALTER TABLE `media_dimensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_variants`
--

DROP TABLE IF EXISTS `media_variants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_variants` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `media_id` bigint unsigned NOT NULL,
  `width` int unsigned NOT NULL,
  `height` int unsigned NOT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `media_variants_media_id_width_height_index` (`media_id`,`width`,`height`),
  CONSTRAINT `media_variants_media_id_foreign` FOREIGN KEY (`media_id`) REFERENCES `media` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_variants`
--

LOCK TABLES `media_variants` WRITE;
/*!40000 ALTER TABLE `media_variants` DISABLE KEYS */;
INSERT INTO `media_variants` VALUES (1,5,300,300,'media/variants/photo-1_1778668374_300x300.jpg','2026-05-13 10:32:54','2026-05-13 10:32:54');
/*!40000 ALTER TABLE `media_variants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2025_08_14_170933_add_two_factor_columns_to_users_table',1),(5,'2026_04_05_070249_create_roles_table',1),(6,'2026_04_05_070250_create_role_user_table',1),(7,'2026_04_05_072705_create_media_table',1),(8,'2026_04_05_072705_create_media_variants_table',1),(9,'2026_04_05_072706_create_media_dimensions_table',1),(10,'2026_04_05_073000_create_posts_table',1),(11,'2026_04_05_073001_create_post_sections_table',1),(12,'2026_04_05_073002_create_categories_table',1),(13,'2026_04_05_073003_create_tags_table',1),(14,'2026_04_05_073004_create_category_post_table',1),(15,'2026_04_05_073005_create_post_tag_table',1),(16,'2026_04_05_073006_create_comments_table',1),(17,'2026_04_05_073007_create_post_views_table',1),(18,'2026_04_05_090059_add_image_columns_to_posts_table',1),(19,'2026_04_05_095746_create_sliders_table',1),(20,'2026_04_05_095747_create_slider_slides_table',1),(21,'2026_05_13_064930_create_gallery_albums_table',2),(22,'2026_05_13_064931_create_gallery_album_images_table',2),(23,'2026_05_16_114105_add_slug_to_gallery_albums_table',3),(24,'2026_05_19_110802_create_board_members_table',4),(25,'2026_05_27_045839_create_explore_pune_places_table',5),(26,'2026_05_27_051939_alter_explore_pune_places_nullable_fields',5),(27,'2026_05_29_154745_create_marquee_items_table',6);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_sections`
--

DROP TABLE IF EXISTS `post_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post_sections` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint unsigned NOT NULL,
  `type` enum('text','image','image_text','gallery','quote') COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` json NOT NULL,
  `position` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `post_sections_post_id_position_index` (`post_id`,`position`),
  CONSTRAINT `post_sections_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_sections`
--

LOCK TABLES `post_sections` WRITE;
/*!40000 ALTER TABLE `post_sections` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_tag`
--

DROP TABLE IF EXISTS `post_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post_tag` (
  `post_id` bigint unsigned NOT NULL,
  `tag_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`post_id`,`tag_id`),
  KEY `post_tag_tag_id_foreign` (`tag_id`),
  CONSTRAINT `post_tag_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `post_tag_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_tag`
--

LOCK TABLES `post_tag` WRITE;
/*!40000 ALTER TABLE `post_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_views`
--

DROP TABLE IF EXISTS `post_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post_views` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint unsigned NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `viewed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `post_views_post_id_viewed_at_index` (`post_id`,`viewed_at`),
  CONSTRAINT `post_views_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_views`
--

LOCK TABLES `post_views` WRITE;
/*!40000 ALTER TABLE `post_views` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_views` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` text COLLATE utf8mb4_unicode_ci,
  `status` enum('draft','published','scheduled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `published_at` timestamp NULL DEFAULT NULL,
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `is_trending` tinyint(1) NOT NULL DEFAULT '0',
  `user_id` bigint unsigned NOT NULL,
  `featured_image_media_id` bigint unsigned DEFAULT NULL,
  `card_image_media_id` bigint unsigned DEFAULT NULL,
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `posts_slug_unique` (`slug`),
  KEY `posts_user_id_foreign` (`user_id`),
  KEY `posts_created_at_index` (`created_at`),
  KEY `posts_status_index` (`status`),
  KEY `posts_published_at_index` (`published_at`),
  KEY `posts_is_featured_index` (`is_featured`),
  KEY `posts_is_trending_index` (`is_trending`),
  KEY `posts_featured_image_media_id_foreign` (`featured_image_media_id`),
  KEY `posts_card_image_media_id_foreign` (`card_image_media_id`),
  CONSTRAINT `posts_card_image_media_id_foreign` FOREIGN KEY (`card_image_media_id`) REFERENCES `media` (`id`) ON DELETE SET NULL,
  CONSTRAINT `posts_featured_image_media_id_foreign` FOREIGN KEY (`featured_image_media_id`) REFERENCES `media` (`id`) ON DELETE SET NULL,
  CONSTRAINT `posts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_user`
--

DROP TABLE IF EXISTS `role_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_user` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_user_user_id_role_id_unique` (`user_id`,`role_id`),
  KEY `role_user_role_id_foreign` (`role_id`),
  CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_user`
--

LOCK TABLES `role_user` WRITE;
/*!40000 ALTER TABLE `role_user` DISABLE KEYS */;
INSERT INTO `role_user` VALUES (1,1,1,NULL,NULL),(2,2,2,NULL,NULL);
/*!40000 ALTER TABLE `role_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin','2026-05-13 10:08:30','2026-05-13 10:08:30'),(2,'user','2026-05-13 10:08:30','2026-05-13 10:08:30');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('11bJtGwULIfW7kqvx2dcrN5yYdlvl3zjjJg020wo',1,'223.188.26.102','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJqdjFXcTRQZzRrcTZVQ1pXSFg4U0ZGZnJCVUsxYUpkTzhzeE01eWlJIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9zdGFnaW5nZGVtby50ZWNoXC9wYXNzZW5nZXItaW5mb1wvcGFzc2VuZ2VyLWFtZW5pdGllcyIsInJvdXRlIjoicGFzc2VuZ2VyLWluZm8ucGFzc2VuZ2VyLWFtZW5pdGllcyJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjoxfQ==',1781689096),('1jLe40AXU1G8HuJviavkle7Y4OenKWY5JOPpLLFp',NULL,'27.107.94.10','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0','eyJfdG9rZW4iOiJhMWU1T21QV0M1amQ4VkxrMFZZSjNkU2czMzdEbW9PME10TXlsRkRHIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119LCJfcHJldmlvdXMiOnsidXJsIjoiaHR0cHM6XC9cL3N0YWdpbmdkZW1vLnRlY2hcL3BvbGljaWVzIiwicm91dGUiOiJwb2xpY2llcyJ9fQ==',1781703662),('1vpwvSCBeqa1uJJaLRWVWPZTuYDDozq7T92prrku',NULL,'172.204.16.73','Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; ChatGPT-User/1.0; +https://openai.com/bot','eyJfdG9rZW4iOiJsaDJodmdMYUd2MDlUSkpCS25rWEdMSmJHRjZDQUhJcXQxcmVoSnpYIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC93d3cuc3RhZ2luZ2RlbW8udGVjaFwvYWJvdXRcL292ZXJ2aWV3Iiwicm91dGUiOiJhYm91dC5vdmVydmlldyJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1781697086),('7zvg4bwcz7v8Zu0IH2cjolc04EhtGINkmOn234zT',NULL,'27.107.94.10','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0','eyJfdG9rZW4iOiJuYk1jRmlvOEhIWjRmeDB5a0ljZ0lRem9pUXlhS0ppUFZLRXlHa1p0IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9zdGFnaW5nZGVtby50ZWNoXC9wcm9qZWN0LXByb2ZpbGVcL3Bob3RvLWdhbGxlcnkiLCJyb3V0ZSI6InByb2plY3QtcHJvZmlsZS5waG90by1nYWxsZXJ5In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1781694114),('aWSAAHewmLaur5IAFPJbgBxBLF2tj6UFnPKz6YwU',1,'157.34.236.63','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJwZzhIRnV5S3hIMUhPT3JhSnBCcGt3V2dHQUhWNnBQaksyMTJqUDh0IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9zdGFnaW5nZGVtby50ZWNoXC9kYXNoYm9hcmRcL2V4cGxvcmUtcHVuZSIsInJvdXRlIjoiZGFzaGJvYXJkLmV4cGxvcmUtcHVuZS5pbmRleCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjoxfQ==',1781694628),('DlyCOFh07xN0R756mMHLNBenQvFFsqkG0mBmGNoP',NULL,'152.58.128.245','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJ2cG1EMUVFdjVhWm9zSVc1Tks1bDFMY3NtVEdrZ014elhJSzU1NlFuIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9zdGFnaW5nZGVtby50ZWNoIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1781697274),('hyFbgfjRcCOaht5kxJcxMkHshOz9sHgRITTpbKkm',1,'182.77.73.91','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJxWGdJU0RLV2l5aGp1MGowVGhvUUhQc1BtRndHeVphc2psYmxLMk9vIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9zdGFnaW5nZGVtby50ZWNoIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjF9',1781697108),('IVvqxo6EY3lBdoN26hqFLnl2bF9HbmUbJNhpIVsW',NULL,'172.204.16.75','Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; ChatGPT-User/1.0; +https://openai.com/bot','eyJfdG9rZW4iOiJnZ203RGtJcW9aMkp2NTk0NG9zR2RVYjJwOGl2a0kzZFJtSlRSdjUzIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9zdGFnaW5nZGVtby50ZWNoXC9yb3V0ZVwvc3RhdGlvbi1saXN0Iiwicm91dGUiOiJyb3V0ZS5zdGF0aW9uLWxpc3QifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1781697082),('oIkUy6m1YaoteehAvqxt6vRjRzvDXjDEpUbwNLYf',NULL,'27.107.94.10','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0','eyJfdG9rZW4iOiJrQXhNcUZ0MjJoVW9NMHpMU2c5NzlEblo2OUN1Q0xqU1VVTWJ2R0VMIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9zdGFnaW5nZGVtby50ZWNoIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1781701779);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slider_slides`
--

DROP TABLE IF EXISTS `slider_slides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `slider_slides` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `slider_id` bigint unsigned NOT NULL,
  `heading_line1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `heading_line2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paragraph` text COLLATE utf8mb4_unicode_ci,
  `desktop_media_id` bigint unsigned DEFAULT NULL,
  `mobile_media_id` bigint unsigned DEFAULT NULL,
  `position` int unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `slider_slides_desktop_media_id_foreign` (`desktop_media_id`),
  KEY `slider_slides_mobile_media_id_foreign` (`mobile_media_id`),
  KEY `slider_slides_slider_id_position_index` (`slider_id`,`position`),
  CONSTRAINT `slider_slides_desktop_media_id_foreign` FOREIGN KEY (`desktop_media_id`) REFERENCES `media` (`id`) ON DELETE SET NULL,
  CONSTRAINT `slider_slides_mobile_media_id_foreign` FOREIGN KEY (`mobile_media_id`) REFERENCES `media` (`id`) ON DELETE SET NULL,
  CONSTRAINT `slider_slides_slider_id_foreign` FOREIGN KEY (`slider_id`) REFERENCES `sliders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slider_slides`
--

LOCK TABLES `slider_slides` WRITE;
/*!40000 ALTER TABLE `slider_slides` DISABLE KEYS */;
/*!40000 ALTER TABLE `slider_slides` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sliders`
--

DROP TABLE IF EXISTS `sliders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sliders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sliders_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sliders`
--

LOCK TABLES `sliders` WRITE;
/*!40000 ALTER TABLE `sliders` DISABLE KEYS */;
/*!40000 ALTER TABLE `sliders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tags_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` VALUES (1,'Line 1','line-1','2026-05-13 10:09:29','2026-05-13 10:09:29'),(2,'Line 2','line-2','2026-05-13 10:09:29','2026-05-13 10:09:29'),(3,'Line 3','line-3','2026-05-13 10:09:29','2026-05-13 10:09:29'),(4,'Aqua Line','aqua-line','2026-05-13 10:09:29','2026-05-13 10:09:29'),(5,'Purple Line','purple-line','2026-05-13 10:09:29','2026-05-13 10:09:29'),(6,'Pink Line','pink-line','2026-05-13 10:09:29','2026-05-13 10:09:29'),(7,'PCMC','pcmc','2026-05-13 10:09:29','2026-05-13 10:09:29'),(8,'Swargate','swargate','2026-05-13 10:09:29','2026-05-13 10:09:29'),(9,'Vanaz','vanaz','2026-05-13 10:09:29','2026-05-13 10:09:29'),(10,'Ramwadi','ramwadi','2026-05-13 10:09:29','2026-05-13 10:09:29'),(11,'Nashik Phata','nashik-phata','2026-05-13 10:09:29','2026-05-13 10:09:29'),(12,'Shivajinagar','shivajinagar','2026-05-13 10:09:29','2026-05-13 10:09:29'),(13,'Civil Court','civil-court','2026-05-13 10:09:29','2026-05-13 10:09:29'),(14,'RTO Colony','rto-colony','2026-05-13 10:09:29','2026-05-13 10:09:29'),(15,'Garware College','garware-college','2026-05-13 10:09:29','2026-05-13 10:09:29'),(16,'Deccan Gymkhana','deccan-gymkhana','2026-05-13 10:09:29','2026-05-13 10:09:29'),(17,'Nal Stop','nal-stop','2026-05-13 10:09:29','2026-05-13 10:09:29'),(18,'Sinhagad Road','sinhagad-road','2026-05-13 10:09:29','2026-05-13 10:09:29'),(19,'Khadki','khadki','2026-05-13 10:09:29','2026-05-13 10:09:29'),(20,'Bhosari','bhosari','2026-05-13 10:09:29','2026-05-13 10:09:29'),(21,'Phulenagar','phulenagar','2026-05-13 10:09:29','2026-05-13 10:09:29'),(22,'Dapodi','dapodi','2026-05-13 10:09:29','2026-05-13 10:09:29'),(23,'Bopodi','bopodi','2026-05-13 10:09:29','2026-05-13 10:09:29'),(24,'Kasarwadi','kasarwadi','2026-05-13 10:09:29','2026-05-13 10:09:29'),(25,'Pimpri','pimpri','2026-05-13 10:09:29','2026-05-13 10:09:29'),(26,'Chinchwad','chinchwad','2026-05-13 10:09:29','2026-05-13 10:09:29'),(27,'Sant Tukaram Nagar','sant-tukaram-nagar','2026-05-13 10:09:29','2026-05-13 10:09:29'),(28,'Bhakti Shakti','bhakti-shakti','2026-05-13 10:09:29','2026-05-13 10:09:29'),(29,'Range Hill','range-hill','2026-05-13 10:09:29','2026-05-13 10:09:29'),(30,'Aundh','aundh','2026-05-13 10:09:29','2026-05-13 10:09:29'),(31,'Wakad','wakad','2026-05-13 10:09:29','2026-05-13 10:09:29'),(32,'Hinjawadi','hinjawadi','2026-05-13 10:09:29','2026-05-13 10:09:29'),(33,'PMRDA','pmrda','2026-05-13 10:09:29','2026-05-13 10:09:29'),(34,'MAHA-METRO','maha-metro','2026-05-13 10:09:29','2026-05-13 10:09:29'),(35,'MSRTC','msrtc','2026-05-13 10:09:29','2026-05-13 10:09:29'),(36,'PMPML','pmpml','2026-05-13 10:09:29','2026-05-13 10:09:29'),(37,'DPR','dpr','2026-05-13 10:09:29','2026-05-13 10:09:29'),(38,'NMC','nmc','2026-05-13 10:09:29','2026-05-13 10:09:29'),(39,'PMC','pmc','2026-05-13 10:09:29','2026-05-13 10:09:29'),(40,'Central Government','central-government','2026-05-13 10:09:30','2026-05-13 10:09:30'),(41,'Phase 1','phase-1','2026-05-13 10:09:30','2026-05-13 10:09:30'),(42,'Phase 2','phase-2','2026-05-13 10:09:30','2026-05-13 10:09:30'),(43,'Phase 3','phase-3','2026-05-13 10:09:30','2026-05-13 10:09:30'),(44,'Underground','underground','2026-05-13 10:09:30','2026-05-13 10:09:30'),(45,'Elevated','elevated','2026-05-13 10:09:30','2026-05-13 10:09:30'),(46,'Depot','depot','2026-05-13 10:09:30','2026-05-13 10:09:30'),(47,'Viaduct','viaduct','2026-05-13 10:09:30','2026-05-13 10:09:30'),(48,'Station Box','station-box','2026-05-13 10:09:30','2026-05-13 10:09:30'),(49,'Smart Card','smart-card','2026-05-13 10:09:30','2026-05-13 10:09:30'),(50,'QR Ticket','qr-ticket','2026-05-13 10:09:30','2026-05-13 10:09:30'),(51,'AFC','afc','2026-05-13 10:09:30','2026-05-13 10:09:30'),(52,'CBTC','cbtc','2026-05-13 10:09:30','2026-05-13 10:09:30'),(53,'DEMU','demu','2026-05-13 10:09:30','2026-05-13 10:09:30'),(54,'Rolling Stock','rolling-stock','2026-05-13 10:09:30','2026-05-13 10:09:30'),(55,'Frequency','frequency','2026-05-13 10:09:30','2026-05-13 10:09:30'),(56,'Schedule','schedule','2026-05-13 10:09:30','2026-05-13 10:09:30'),(57,'Feeder Bus','feeder-bus','2026-05-13 10:09:30','2026-05-13 10:09:30'),(58,'Last Mile Connectivity','last-mile-connectivity','2026-05-13 10:09:30','2026-05-13 10:09:30'),(59,'Park and Ride','park-and-ride','2026-05-13 10:09:30','2026-05-13 10:09:30'),(60,'Multimodal Hub','multimodal-hub','2026-05-13 10:09:30','2026-05-13 10:09:30'),(61,'Solar Energy','solar-energy','2026-05-13 10:09:30','2026-05-13 10:09:30'),(62,'Green Metro','green-metro','2026-05-13 10:09:30','2026-05-13 10:09:30'),(63,'IGBC','igbc','2026-05-13 10:09:30','2026-05-13 10:09:30'),(64,'Carbon Neutral','carbon-neutral','2026-05-13 10:09:30','2026-05-13 10:09:30'),(65,'Inauguration','inauguration','2026-05-13 10:09:30','2026-05-13 10:09:30'),(66,'Trial Run','trial-run','2026-05-13 10:09:30','2026-05-13 10:09:30'),(67,'Commercial Operation','commercial-operation','2026-05-13 10:09:30','2026-05-13 10:09:30'),(68,'Land Acquisition','land-acquisition','2026-05-13 10:09:30','2026-05-13 10:09:30'),(69,'Tender','tender','2026-05-13 10:09:30','2026-05-13 10:09:30'),(70,'Safety','safety','2026-05-13 10:09:30','2026-05-13 10:09:30'),(71,'Accessibility','accessibility','2026-05-13 10:09:30','2026-05-13 10:09:30');
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Admin User','admin@pune-metro.com','2026-05-13 10:08:30','$2y$12$8.Vv7P4XfGVxdkFFPyW/DepRbtdvHuXrtiWCZKDL.gvtCdzz44Iku',NULL,NULL,NULL,'ys6r0Cnr6VkSTcMFtymXslnchJfA9G590MbFfhi9uj6FFJFU8vJCfO4KB16i','2026-05-13 10:08:30','2026-05-13 10:08:30'),(2,'Test User','test@pune-metro.com','2026-05-13 10:08:30','$2y$12$8.Vv7P4XfGVxdkFFPyW/DepRbtdvHuXrtiWCZKDL.gvtCdzz44Iku',NULL,NULL,NULL,'APCQymRbfR','2026-05-13 10:08:30','2026-05-13 10:08:30');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-17 18:15:12
